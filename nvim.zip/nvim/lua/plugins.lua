-- Bootstrap lazy.nvim
local lazypath = vim.fn.stdpath("data") .. "/lazy/lazy.nvim"
if not (vim.uv or vim.loop).fs_stat(lazypath) then
  vim.fn.system({
    "git", "clone", "--filter=blob:none", "--branch=stable",
    "https://github.com/folke/lazy.nvim.git",
    lazypath,
  })
end
vim.opt.rtp:prepend(lazypath)

require("lazy").setup({
  -- Theme
  {
    "catppuccin/nvim",
    name = "catppuccin",
    config = function()
      require("catppuccin").setup({
        flavour = "mocha",
      })
      vim.cmd.colorscheme("catppuccin")
    end,
  },

  -- Git
  "tpope/vim-fugitive",
  { "lewis6991/gitsigns.nvim", config = true },

  -- tmux navigation
  "christoomey/vim-tmux-navigator",

  -- undotree 
  "mbbill/undotree",

  -- Copilot (keep your behavior)
  {
    "github/copilot.vim",
    init = function()
      vim.g.copilot_enabled = 0
    end,
  },

  -- Treesitter (better syntax/highlights than vim-polyglot)
  { "nvim-treesitter/nvim-treesitter", build = ":TSUpdate" },

  -- Navigation Leap
  { 
    url="https://codeberg.org/andyg/leap.nvim", 
    config = function()
      require("leap").add_default_mappings()
    end,
  },

  -- File tree (NERDTree replacement)
  {
    "nvim-neo-tree/neo-tree.nvim",
    branch = "v3.x",
    dependencies = {
      "nvim-lua/plenary.nvim",
      "nvim-tree/nvim-web-devicons",
      "MunifTanjim/nui.nvim",
    },
    config = function()
      require("neo-tree").setup({
        filesystem = { follow_current_file = { enabled = true } },
      })
    end,
  },

  -- Fuzzy finder (fzf.vim replacement)
  {
    "nvim-telescope/telescope.nvim",
    dependencies = { 
      "nvim-lua/plenary.nvim",
      {
        "nvim-telescope/telescope-fzf-native.nvim",
        build = "make",
      },
    },
    config = function()
      local telescope = require("telescope")

      telescope.setup({
        extensions = {
          fzf = {
            fuzzy = true,                    -- enables fuzzy matching
            override_generic_sorter = true,  -- makes generic pickers fuzzy
            override_file_sorter = true,     -- makes find_files fuzzy
            case_mode = "smart_case",
          },
        },
      })

      telescope.load_extension("fzf")

      local builtin = require("telescope.builtin")
      vim.keymap.set("n", "<Leader><Leader>", builtin.buffers, { silent = true })
      vim.keymap.set("n", "<Leader>ff", function()
        builtin.find_files()
      end, { silent = true })

      -- keep your old muscle-memory commands
      vim.api.nvim_create_user_command("Rg", function() builtin.live_grep() end, {})
      vim.api.nvim_create_user_command("Buffers", function() builtin.buffers() end, {})
    end,
  },

  -- Fuzzy String Search
  {
    "ibhagwan/fzf-lua",
    dependencies = { "nvim-tree/nvim-web-devicons" },
    config = function()
      require("fzf-lua").setup({
        winopts = {
          height = 0.85,
          width = 0.80,
          preview = { layout = "vertical" },
        },
        fzf_opts = {
          ["--layout"] = "reverse-list",
        }
      })
    end,
  },

  -- Terminal (floaterm replacement; keeps your <Leader>tt)
  {
    "akinsho/toggleterm.nvim",
    version = "*",
    config = function()
      require("toggleterm").setup({
        direction = "float",

        float_opts = {
          border = "curved",
          width = function()
            return math.floor(vim.o.columns * 0.8)
          end,
          height = function()
            return math.floor(vim.o.lines * 0.8)
          end,
        },

        on_exit = function(term, job, exit_code, name)
          if exit_code == 0 then
            term:close()
          end
        end,
      })
    end,
  },

  -- LSP core
  "mason-org/mason.nvim",  -- install/manage servers :contentReference[oaicite:7]{index=7}
  "mason-org/mason-lspconfig.nvim",

  -- Rust superpowers
  {
    "mrcjkb/rustaceanvim", -- rust-analyzer integration :contentReference[oaicite:8]{index=8}
    version = "^5",
    ft = { "rust" },
  },

  -- Completion
  "hrsh7th/nvim-cmp",
  "hrsh7th/cmp-nvim-lsp",
  "L3MON4D3/LuaSnip",
  "saadparwaiz1/cmp_luasnip",

  -- Formatting (simple + fast)
  "stevearc/conform.nvim",
})

