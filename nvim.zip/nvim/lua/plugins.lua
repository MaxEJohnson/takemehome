-- Bootstrap lazy.nvim
local lazypath = vim.fn.stdpath("data") .. "/lazy/lazy.nvim"
if not (vim.uv or vim.loop).fs_stat(lazypath) then
  vim.fn.system({
    "git", "clone", "--filter=blob:none", "--branch=stable",
    "https://github.com/folke/lazy.nvim.git",
    lazypath,
  })
end
vim.opt.rtp:prepend(lazypath)

require("lazy").setup({
  -- Theme
  {
    "catppuccin/nvim",
    name = "catppuccin",
    priority = 1000,
    config = function()
      vim.cmd.colorscheme("catppuccin")
    end,
  },

  -- Git
  "tpope/vim-fugitive",
  { "lewis6991/gitsigns.nvim", config = true },

  -- tmux navigation
  "christoomey/vim-tmux-navigator",

  -- undotree 
  "mbbill/undotree",

  -- Copilot (keep your behavior)
  {
    "github/copilot.vim",
    init = function()
      vim.g.copilot_enabled = 0
    end,
  },

  -- Treesitter (better syntax/highlights than vim-polyglot)
  { "nvim-treesitter/nvim-treesitter", build = ":TSUpdate" },

  -- File tree (NERDTree replacement)
  {
    "nvim-neo-tree/neo-tree.nvim",
    branch = "v3.x",
    dependencies = {
      "nvim-lua/plenary.nvim",
      "nvim-tree/nvim-web-devicons",
      "MunifTanjim/nui.nvim",
    },
    config = function()
      require("neo-tree").setup({
        filesystem = { follow_current_file = { enabled = true } },
      })
      vim.keymap.set("n", "<Leader>ee", ":Neotree reveal<CR>", { silent = true })
    end,
  },

  -- Fuzzy finder (fzf.vim replacement)
  {
    "nvim-telescope/telescope.nvim",
    dependencies = { "nvim-lua/plenary.nvim" },
    config = function()
      local telescope = require("telescope")
      telescope.setup({})
      local builtin = require("telescope.builtin")
      vim.keymap.set("n", "<Leader><Leader>", builtin.buffers, { silent = true })
      vim.keymap.set("n", "<Leader>ff", function()
        builtin.live_grep() -- ripgrep-backed
      end, { silent = true })

      -- keep your old muscle-memory commands
      vim.api.nvim_create_user_command("Rg", function() builtin.live_grep() end, {})
      vim.api.nvim_create_user_command("Buffers", function() builtin.buffers() end, {})
    end,
  },

  -- Terminal (floaterm replacement; keeps your <Leader>tt)
  {
    "akinsho/toggleterm.nvim",
    version = "*",
    config = function()
      require("toggleterm").setup({
        open_mapping = [[<c-\>]],
        direction = "float",
        float_opts = { border = "curved" },
      })
    end,
  },

  -- LSP core
  "mason-org/mason.nvim",  -- install/manage servers :contentReference[oaicite:7]{index=7}
  "mason-org/mason-lspconfig.nvim",

  -- Rust superpowers
  {
    "mrcjkb/rustaceanvim", -- rust-analyzer integration :contentReference[oaicite:8]{index=8}
    version = "^5",
    ft = { "rust" },
  },

  -- Completion
  "hrsh7th/nvim-cmp",
  "hrsh7th/cmp-nvim-lsp",
  "L3MON4D3/LuaSnip",
  "saadparwaiz1/cmp_luasnip",

  -- Formatting (simple + fast)
  "stevearc/conform.nvim",
})

