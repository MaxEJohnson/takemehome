vim.g.mapleader = " "

vim.opt.syntax = "on"
vim.opt.termguicolors = true

-- UI
vim.opt.number = true
vim.opt.relativenumber = true
vim.opt.scrolloff = 8
vim.opt.cursorline = true
vim.opt.laststatus = 2
vim.opt.showcmd = true
vim.opt.ruler = true

-- Tabs / indent
vim.opt.expandtab = true
vim.opt.tabstop = 4
vim.opt.shiftwidth = 4
vim.opt.autoindent = true
vim.opt.smartindent = true

-- Search
vim.opt.ignorecase = true
vim.opt.smartcase = true
vim.opt.hlsearch = true
vim.opt.incsearch = true

-- Timing
vim.opt.updatetime = 300
vim.opt.timeoutlen = 500

-- Tags
vim.opt.tags = { "tags", "tags;~" }

-- ripgrep as grepprg
vim.opt.grepprg = "rg --vimgrep --no-heading --smart-case"

-- Save all on focus lost (your behavior)
vim.api.nvim_create_autocmd("FocusLost", {
  pattern = "*",
  command = "silent! wall",
})

-- Undo
vim.opt.undofile = true
