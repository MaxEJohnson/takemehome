-- Mason (optional but convenient for installs)
require("mason").setup()

-- If you keep mason-lspconfig, it's mainly for :LspInstall convenience on 0.11+
-- (it no longer needs to auto-configure servers)
pcall(function()
  require("mason-lspconfig").setup({
    ensure_installed = { "clangd" },
  })
end)

-- Completion (cmp)
local cmp = require("cmp")
cmp.setup({
  snippet = {
    expand = function(args) require("luasnip").lsp_expand(args.body) end,
  },
  mapping = cmp.mapping.preset.insert({
    ["<CR>"] = cmp.mapping.confirm({ select = true }),
    ["<Tab>"] = cmp.mapping.select_next_item(),
    ["<S-Tab>"] = cmp.mapping.select_prev_item(),
  }),
  sources = {
    { name = "nvim_lsp" },
    { name = "luasnip" },
  },
})

-- LSP keymaps (buffer-local)
vim.api.nvim_create_autocmd("LspAttach", {
  callback = function(args)
    local bufnr = args.buf
    local map = function(mode, lhs, rhs)
      vim.keymap.set(mode, lhs, rhs, { buffer = bufnr, silent = true })
    end
    map("n", "K", vim.lsp.buf.hover)
    map("n", "gr", vim.lsp.buf.references)
    map("n", "<Leader>rn", vim.lsp.buf.rename)
    map("n", "<Leader>ca", vim.lsp.buf.code_action)
  end,
})

-- Capabilities for completion
local capabilities = require("cmp_nvim_lsp").default_capabilities()

vim.lsp.config("clangd", {
  cmd = { "clangd", "--background-index" },
  filetypes = { "c", "cpp", "objc", "objcpp" },
  root_markers = { "compile_commands.json", "compile_flags.txt", ".git" },
  capabilities = capabilities,
})

vim.lsp.enable({ "clangd" })

-- Formatting
require("conform").setup({
  format_on_save = function()
    return { timeout_ms = 2000, lsp_fallback = true }
  end,
  formatters = {
    rustfmt = {
      prepend_args = { "--color", "never" },
    },
  },
  formatters_by_ft = {
    rust = { "rustfmt" },
    c = { "clang_format" },
    cpp = { "clang_format" },
  },
})

