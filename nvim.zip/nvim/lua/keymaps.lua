local map = vim.keymap.set

-- Your insert escape + save
map("i", "jk", "<Esc>:w<CR>", { silent = true })

-- Blackhole changes/deletes like you do
map("n", "c", '"_c')
map("n", "x", '"_x')

-- Center search results
map("n", "n", "nzzzv")
map("n", "N", "Nzzzv")

-- Clipboard yanks
map({ "n", "v" }, "<Leader>y", '"+y')

-- Window / tab
map("n", "<Leader>sv", ":vsplit<CR><C-w>w", { silent = true })
map("n", "<Leader>td", "<C-w>w", { silent = true })
map("n", "<Leader>to", ":tabnew %<CR>", { silent = true })
map("n", "<Leader>tf", ":vertical resize 200<CR>", { silent = true })

-- Buffers
map("n", "<Leader>bd", ":bd<CR>", { silent = true })

-- :W alias
vim.api.nvim_create_user_command("W", "w", {})

-- Git (we'll use fugitive still)
map("n", "<Leader>gs", ":Git<CR>", { silent = true })
map("n", "<Leader>gd", ":Gdiffsplit<CR>", { silent = true })

-- LSP stop (Neovim equivalent)
map("n", "<Leader>ls", ":LspStop<CR>", { silent = true })

-- Terminal (we’ll use toggleterm)
map("n", "<Leader>tt", ":ToggleTerm direction=vertical<CR>", { silent = true })

-- Diagnostic Warnings/Errors
map("n", "<Leader>e", vim.diagnostic.open_float)

-- UndoTree
map("n", "<Leader>u", vim.cmd.UndotreeToggle)

