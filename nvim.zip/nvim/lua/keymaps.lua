local map = vim.keymap.set

-- Your insert escape + save
map("i", "jk", "<Esc>:w<CR>", { silent = true })

-- Blackhole changes/deletes like you do
map("n", "c", '"_c')
map("n", "x", '"_x')

-- Center search results
map("n", "n", "nzzzv")
map("n", "N", "Nzzzv")

-- Clipboard yanks
map({ "n", "v" }, "<Leader>y", '"+y')

-- Window / tab
map("n", "<Leader>sv", ":vsplit<CR><C-w>w", { silent = true })
map("n", "<Leader>td", "<C-w>w", { silent = true })
map("n", "<Leader>to", ":tabnew %<CR>", { silent = true })
map("n", "<Leader>tf", ":vertical resize 200<CR>", { silent = true })

-- Buffers
map("n", "<Leader>bd", ":bd<CR>", { silent = true })

-- :W alias
vim.api.nvim_create_user_command("W", "w", {})

-- Git (we'll use fugitive still)
map("n", "<Leader>gs", ":Git<CR>", { silent = true })
map("n", "<Leader>gd", ":Gdiffsplit<CR>", { silent = true })
map("n", "<Leader>gb", ":Git blame<CR>", { silent = true })

-- LSP stop (Neovim equivalent)
map("n", "<Leader>ls", ":LspStop<CR>", { silent = true })

-- Terminal (we’ll use toggleterm)
map("n", "<Leader>tt", "<cmd>ToggleTerm<CR>", { silent = true })

-- Diagnostic Warnings/Errors
map("n", "<Leader>e", vim.diagnostic.open_float)

-- UndoTree
map("n", "<Leader>u", vim.cmd.UndotreeToggle)

-- Fuzzy String Search
map("n", "<Leader>fs", function()
  require("fzf-lua").grep_project({
    search = "",
    rg_opts = table.concat({
      "--line-number",
      "--no-heading",
      "--color=never",
      "--smart-case",
      "--hidden",
      "--glob", "!.git/*",
    }, " "),
    winopts = { preview = { hidden = "hidden" } },
    fzf_opts = {
      ["--layout"] = "reverse-list",
    }
  })
end, { silent = true })

-- wipe any existing mappings first (so init.lua can't "win")
pcall(vim.keymap.del, "n", "s")
pcall(vim.keymap.del, "x", "s")
pcall(vim.keymap.del, "o", "s")
pcall(vim.keymap.del, "n", "S")
pcall(vim.keymap.del, "x", "S")
pcall(vim.keymap.del, "o", "S")

-- map directly to the working Lua function
vim.keymap.set({ "n", "x", "o" }, "s", function()
  require("leap").leap({})
end, { silent = true })

vim.keymap.set({ "n", "x", "o" }, "S", function()
  require("leap").leap({ backward = true })
end, { silent = true })

-- Neotree toggle
vim.keymap.set("n", "<Leader>ee", function()
  if vim.bo.filetype == "neo-tree" then
    -- We are inside Neo-tree → close it
    vim.cmd("Neotree close")
  else
    -- In a regular file → reveal this file
    vim.cmd("Neotree reveal")
  end
end, { silent = true, desc = "Neo-tree reveal/toggle" })

